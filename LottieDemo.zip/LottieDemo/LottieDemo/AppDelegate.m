//
//  AppDelegate.m
//  LottieDemo
//
//  Created by 全栈会 on 2022/1/26.
//

#import "AppDelegate.h"
#import "FirstViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    //  设置根控制器
    self.window = [[UIWindow alloc]init];
    
    self.window.frame = [UIScreen mainScreen].bounds;
    
    self.window.backgroundColor = [UIColor whiteColor];
            
    FirstViewController *vc = [[FirstViewController alloc] init];
                    
    self.window.rootViewController = vc;
            
    [self.window makeKeyAndVisible];

    return YES;
}



@end
